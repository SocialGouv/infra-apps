# kube-image-keeper (kuik)

[![Releases](https://github.com/enix/kube-image-keeper/actions/workflows/release.yaml/badge.svg?branch=v2)](https://github.com/enix/kube-image-keeper/releases)
[![Go report card](https://goreportcard.com/badge/github.com/enix/kube-image-keeper)](https://goreportcard.com/report/github.com/enix/kube-image-keeper)
[![MIT license](https://img.shields.io/badge/License-MIT-blue.svg)](https://opensource.org/licenses/MIT)
[![Brought to you by Enix](https://img.shields.io/badge/Brought%20to%20you%20by-ENIX-%23377dff?labelColor=888&logo=data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAAOCAQAAAC1QeVaAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAAmJLR0QA/4ePzL8AAAAHdElNRQfkBAkQIg/iouK/AAABZ0lEQVQY0yXBPU8TYQDA8f/zcu1RSDltKliD0BKNECYZmpjgIAOLiYtubn4EJxI/AImzg3E1+AGcYDIMJA7lxQQQQRAiSSFG2l457+655x4Gfz8B45zwipWJ8rPCQ0g3+p9Pj+AlHxHjnLHAbvPW2+GmLoBN+9/+vNlfGeU2Auokd8Y+VeYk/zk6O2fP9fcO8hGpN/TUbxpiUhJiEorTgy+6hUlU5N1flK+9oIJHiKNCkb5wMyOFw3V9o+zN69o0Exg6ePh4/GKr6s0H72Tc67YsdXbZ5gENNjmigaXbMj0tzEWrZNtqigva5NxjhFP6Wfw1N1pjqpFaZQ7FAY6An6zxTzHs0BGqY/NQSnxSBD6WkDRTf3O0wG2Ztl/7jaQEnGNxZMdy2yET/B2xfGlDagQE1OgRRvL93UOHqhLnesPKqJ4NxLLn2unJgVka/HBpbiIARlHFq1n/cWlMZMne1ZfyD5M/Aa4BiyGSwP4Jl3UAAAAldEVYdGRhdGU6Y3JlYXRlADIwMjAtMDQtMDlUMTQ6MzQ6MTUrMDI6MDDBq8/nAAAAJXRFWHRkYXRlOm1vZGlmeQAyMDIwLTA0LTA5VDE0OjM0OjE1KzAyOjAwsPZ3WwAAAABJRU5ErkJggg==)](https://enix.io)

**kuik** (pronounced /kwɪk/, like "quick") is the shortname of **kube-image-keeper**, a container image routing, mirroring and replication system for Kubernetes developed by Enix. It helps make applications more highly available by ensuring reliable access to container images.

## 🚀 Status: General Availability

> [!NOTE]
> kuik v2 is a **complete rewrite** of the project with a focus on **simplicity** and **ease of use**.

> [!CAUTION]
> Not recommended for production use yet. Kuik v2 is currently being battle tested on several clusters.

## What's new in v2 !

Mostly a redesigned architecture

- **Minimal default features**: core functionality enabled by default, others opt-in
- **Image routing**: kuik can rewrite Pod images on-the-fly to point to an operational registry
- **Image replication**: kuik can manage copy between registries to create a virtual highly available registry
- **Image monitoring**: kuik can monitor image availability across various registries (planned for v2.2)
- **Redesigned CRDs** for better clarity and extensibility

## When to use Kube Image Keeper

### ✅ Overcome public registry limitations
- You face an image pull rate limit
- Your upstream registry is no longer available

&emsp;[Implementation guide](/docs/use-case/overcome-public-registry-limitations.md)

### ✅ Detect missing images before outage
- You plan a maintenance which will reschedule a lot of pods on new workers
- You plan a Kubernetes upgrade
- You have a lot of legacy images deployed on your cluster

&emsp;[Implementation guide](/docs/use-case/detect-missing-images-before-outage.md)

### ✅ Protect images from garbage collect
- You have an aggressive garbage collect
- You have plenty of images (outdated, prior versions, development version) but only a small fraction is being used in reality
- You would like to push only a subset of useful images to your production registry

&emsp;[Implementation guide](/docs/use-case/protect-images-from-garbage-collect.md)

### ✅ Automatically route images to a proxy cache registry
- You already have setup a proxy cache registry (like Harbor or Gitlab proxy cache) but do not know how to use it
- You do not want to review all workloads deployments (and change their image path)

&emsp;[Implementation guide](/docs/use-case/automatically-route-images-to-a-proxy-cache-registry.md)

### ✅ Better performance with local registry
- You use a development registry (ex: gitlab, maven, ...) for production Kubernetes clusters.
- Your registry is overloaded.
- Image pull from Kubernetes are too slow / long.
- Your source registry is too far away (from a network / geographic / latency standpoint) from the Kubernetes cluster

&emsp;[Implementation guide](/docs/use-case/better-performance-with-local-registry.md)

## 📅 Releases & Roadmap

### Already available

- [**v2.0**](https://github.com/enix/kube-image-keeper/releases/tag/v2.1.0) We announced the launch of version 2.0 (General Availability) at the [Cloud Native Days France 2026 convention](https://www.cloudnativedays.fr/)
- [**v2.1**](https://github.com/enix/kube-image-keeper/releases/tag/v2.1.0) Priorities for routing and replication are now a thing
  - [**v2.1.1**](https://github.com/enix/kube-image-keeper/releases/tag/v2.1.1) Fix concurrent access to a single registry (in particular regarding the garbage collect mechanism) by multiple Kuik instances on multiple clusters
- [**v2.2**](https://github.com/enix/kube-image-keeper/releases/tag/v2.2.0) Complete implementation of the **Image monitoring** feature with associated metrics

### Planned features

- **v2.3** Various quality of life improvements
  - Better filtering for cluster wide resources (`includeNamespace` & `excludeNamespace`)
  - Optional monitoring of mirrored images with re-mirroring when needed
- **v2.4** Improve stability of critical components (such as the mutating webhook) by deploying them individually

## 🚧 Known limitations to date

- ~~Mirrored images are considered replicated even if the image was later deleted~~ fixed in `v2.1.1`
- Competition between Kuik's cluster wide custom resources and namespaced resources might lead to weird scenarios (to be partially fixed in `v2.1.1`)
- The mutating webhook do not support the Pod `Update` call
- With replication enabled from registry A to registry B, launching a Pod with image on B will be rerouted (rewritten) to image on A
- Digest tags are not supported, ex: `@sha256:cb4e4ffc5789fd5ff6a534e3b1460623df61cba00f5ea1c7b40153b5efb81805`

## 📦 Installation

```bash
kubectl create namespace kuik-system
VERSION=2.2.2 # Latest available beta version
helm upgrade --install --namespace kuik-system kube-image-keeper oci://quay.io/enix/charts/kube-image-keeper:$VERSION
```

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| configuration.metrics.imageLastMonitorAgeMinutes.bucketFactor | float | `1.1` |  |
| configuration.metrics.imageLastMonitorAgeMinutes.legacy.bucketType | string | `"exponential"` |  |
| configuration.metrics.imageLastMonitorAgeMinutes.legacy.count | int | `12` |  |
| configuration.metrics.imageLastMonitorAgeMinutes.legacy.factor | float | `1.94` |  |
| configuration.metrics.imageLastMonitorAgeMinutes.legacy.start | int | `1` |  |
| configuration.metrics.imageLastMonitorAgeMinutes.maxBucketNumber | int | `20` |  |
| configuration.metrics.imageLastMonitorAgeMinutes.zeroThreshold | float | `1` |  |
| configuration.monitoring.registries.default.interval | string | `"3h"` |  |
| configuration.monitoring.registries.default.maxPerInterval | int | `25` |  |
| configuration.monitoring.registries.default.method | string | `"HEAD"` |  |
| configuration.monitoring.registries.items."docker.io".interval | string | `"1h"` |  |
| configuration.monitoring.registries.items."docker.io".maxPerInterval | int | `6` |  |
| configuration.routing.activeCheck.timeout | string | `"1s"` |  |
| configuration.routing.rewriteOnNeverImagePullPolicy | bool | `false` |  |
| manager.affinity | object | `{}` | Affinity for the manager pod |
| manager.deploymentStrategy | object | `{}` | Deployment strategy for the manager pod |
| manager.env | list | `[]` | Extra env variables for the manager pod |
| manager.image.pullPolicy | string | `"IfNotPresent"` | Manager image pull policy |
| manager.image.repository | string | `"quay.io/enix/kube-image-keeper"` | Manager image repository |
| manager.image.tag | string | `""` | Manager image tag. Default chart appVersion |
| manager.imagePullSecrets | list | `[]` | Specify secrets to be used when pulling manager image |
| manager.livenessProbe | object | `{"httpGet":{"path":"/healthz","port":8081}}` | Liveness probe definition for the manager pod |
| manager.nodeSelector | object | `{}` | Node selector for the manager pod |
| manager.pdb.create | bool | `false` | Create a PodDisruptionBudget for the manager pod |
| manager.pdb.maxUnavailable | string | `""` | Maximum unavailable pods |
| manager.pdb.minAvailable | int | `1` | Minimum available pods |
| manager.podAnnotations | object | `{}` | Annotations to add to the manager pod |
| manager.podSecurityContext | object | `{}` | Security context for the manager pod |
| manager.priorityClassName | string | `""` | Set the PriorityClassName for the manager pod |
| manager.readinessProbe | object | `{"httpGet":{"path":"/readyz","port":8081}}` | Readiness probe definition for the manager pod |
| manager.replicas | int | `1` | Number of manager pods |
| manager.resources.limits.cpu | string | `"1"` | Cpu limits for the manager pod |
| manager.resources.limits.memory | string | `"512Mi"` | Memory limits for the manager pod |
| manager.resources.requests.cpu | string | `"50m"` | Cpu requests for the manager pod |
| manager.resources.requests.memory | string | `"50Mi"` | Memory requests for the manager pod |
| manager.securityContext | object | `{}` | Security context for containers of the manager pod |
| manager.serviceMonitor.create | bool | `false` | Should a ServiceMonitor object be installed to scrape kuik manager metrics. For prometheus-operator (kube-prometheus) users. |
| manager.serviceMonitor.extraLabels | object | `{}` | Additional labels to add to ServiceMonitor objects |
| manager.serviceMonitor.relabelings | list | `[]` | Relabel config for the ServiceMonitor, see: https://coreos.com/operators/prometheus/docs/latest/api.html#relabelconfig |
| manager.serviceMonitor.scrapeInterval | string | `"60s"` | Target scrape interval set in the ServiceMonitor |
| manager.serviceMonitor.scrapeTimeout | string | `"30s"` | Target scrape timeout set in the ServiceMonitor |
| manager.tolerations | list | `[]` | Toleration for the manager pod |
| manager.topologySpreadConstraints | list | `[]` | Topology spread constraints for the manager pod |
| manager.verbosity | string | `"INFO"` | Manager logging verbosity |
| manager.webhook.certificateIssuerRef | object | `{"kind":"Issuer","name":"kube-image-keeper-selfsigned-issuer"}` | Issuer reference to issue the webhook certificate, ignored if createCertificateIssuer is true |
| manager.webhook.createCertificateIssuer | bool | `true` | If true, create the issuer used to issue the webhook certificate |
| manager.webhook.namespaceSelector | object | `{}` | Namespace selector to filter what pods the mutating webhook will rewrite |
| rbac.create | bool | `true` | Create the ClusterRole and ClusterRoleBinding. If false, need to associate permissions with serviceAccount outside this Helm chart. |
| serviceAccount.annotations | object | `{}` | Annotations to add to the serviceAccount |
| serviceAccount.create | bool | `true` | Create the serviceAccount. If false, use serviceAccount with specified name (or "default" if false and name unset.) |
| serviceAccount.extraLabels | object | `{}` | Additional labels to add to the serviceAccount |
| serviceAccount.name | string | `""` | Name of the serviceAccount (auto-generated if unset and create is true) |
| unusedImageTTL | int | `24` | Delay in hours before deleting an Image that is not used by any pod |

## License

MIT License

Copyright (c) 2020-2025 Enix SAS

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
